<?php

namespace App\Http\Controllers;

class PageController extends Controller
{
    public function contact()
    {
        return '<h1>Contact Us</h1><p>Reach out to the department for any laboratory inquiries.</p>';
    }

    public function course($code, $section)
    {
        return "<h1>Course Enrollment</h1><p>Viewing details for Course: " . strtoupper($code) . " | Section: " . $section . "</p>";
    }
}