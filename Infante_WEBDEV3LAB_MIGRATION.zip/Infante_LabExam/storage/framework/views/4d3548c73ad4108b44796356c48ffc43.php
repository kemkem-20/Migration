

<?php $__env->startSection('title', 'Contact Us'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Get in Touch</h1>
    <p>Reach out to our team via email or visit our university laboratory workstation.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Itsuk\Desktop\Infante_LabExam\resources\views/contact.blade.php ENDPATH**/ ?>