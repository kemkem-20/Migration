

<?php $__env->startSection('title', 'Home Page'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Welcome to Our Homepage</h1>
    <p>This page was successfully migrated from native PHP to Laravel Blade templates!</p>
    <p>Explore our navigation bar above to view other pages seamlessly without duplicating HTML structure.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Itsuk\Desktop\Infante_LabExam\resources\views/home.blade.php ENDPATH**/ ?>