<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Infante | WEBDEV3 Laboratory Exam</title>
  <style>
    * { box-sizing: border-box; }
    body {
      margin: 0;
      font-family: Verdana, Geneva, sans-serif;
      line-height: 1.7;
      color: #1d2b33;
      background: #f3f7f9;
    }
    header {
      background: #12425a;
      color: #fff;
      padding: 14px 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 10px;
    }
    header strong { font-size: 1.1rem; }
    nav a { color: #cfe6f1; text-decoration: none; margin-left: 18px; }
    nav a:hover, nav a:focus { color: #fff; text-decoration: underline; }
    .hero {
      background: #12425a;
      color: #fff;
      padding: 70px 20px 80px;
      text-align: center;
    }
    .hero h1 { font-size: 2.4rem; margin: 0 0 10px; }
    .hero p { max-width: 520px; margin: 0 auto 24px; color: #cfe6f1; }
    .button {
      display: inline-block;
      background: #ffd24a;
      color: #1d2b33;
      padding: 10px 22px;
      border-radius: 6px;
      text-decoration: none;
      font-weight: bold;
    }
    main { max-width: 720px; margin: 0 auto; padding: 10px 20px 40px; }
    section { padding: 30px 0 10px; }
    h2 { color: #12425a; border-bottom: 3px solid #ffd24a; display: inline-block; }
    ul { padding-left: 20px; }
    .projects { display: grid; gap: 14px; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); }
    .project { background: #fff; border: 1px solid #d3e0e7; border-radius: 8px; padding: 14px 16px; }
    .project h3 { margin: 0 0 4px; color: #12425a; }
    .project p { margin: 0; font-size: 0.92rem; }
    footer { background: #12425a; color: #cfe6f1; text-align: center; padding: 18px; font-size: 0.9rem; }
  </style>
</head>
<body>
  <header>
    <strong>Infante</strong>
    <nav>
      <a href="#about">About</a>
      <a href="#projects">Projects</a>
      <a href="#contact">Contact</a>
    </nav>
  </header>

  <div class="hero">
    <h1>Hi, I'm Infante</h1>
    <p>A student at Trimex Colleges learning how to build websites with HTML, CSS, and Laravel.</p>
    <a class="button" href="#projects">See my work</a>
  </div>

  <main>
    <section id="about">
      <h2>About me</h2>
      <p>I'm taking Web Development 3 and building my first Laravel project. This website is my laboratory exam output, running on Lubuntu.</p>
      <ul>
        <li>Course: Web Development 3</li>
        <li>School: Trimex Colleges</li>
        <li>Tools: HTML, CSS, PHP, Laravel, SQLite</li>
      </ul>
    </section>

    <section id="projects">
      <h2>Projects</h2>
      <div class="projects">
        <div class="project">
          <h3>Lab Exam Website</h3>
          <p>This page, built with Laravel and plain CSS.</p>
        </div>
        <div class="project">
          <h3>Personal Page</h3>
          <p>My first HTML page with a heading, a paragraph, and a list.</p>
        </div>
        <div class="project">
          <h3>Coming soon</h3>
          <p>More projects will be added here as I learn.</p>
        </div>
      </div>
    </section>

    <section id="contact">
      <h2>Contact</h2>
      <p>Want to say hi? Email me at <a href="mailto:yourname@example.com">yourname@example.com</a>.</p>
    </section>
  </main>

  <footer>&copy; 2026 Infante. Made for the WEBDEV3 Laboratory Exam.</footer>
</body>
</html><?php /**PATH C:\Users\Itsuk\Infante_LabExam\resources\views/welcome.blade.php ENDPATH**/ ?>