

<?php $__env->startSection('title', 'About Us'); ?>

<?php $__env->startSection('content'); ?>
    <h1>About Our System</h1>
    <p>Learn more about our institutional mission, course objectives, and student web development projects.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Itsuk\Desktop\Infante_LabExam\resources\views/about.blade.php ENDPATH**/ ?>