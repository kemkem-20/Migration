<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PageController;

Route::get('/', function () {
    return view('welcome');
});
Route::get('/contact', function () {
    return '<h1>Contact Us</h1><p>Reach out to the department for any laboratory inquiries.</p>';
});
Route::get('/course/{code}/{section}', function ($code, $section) {
    return "<h1>Course Enrollment</h1><p>Viewing details for Course: " . strtoupper($code) . " | Section: " . $section . "</p>";
});
Route::get('/admin-dashboard', function () {
    return "<h1>Admin Dashboard</h1><p>Access granted. Welcome, Administrator.</p>";
})
->middleware('checkRole');
Route::fallback(function () {
    return "<h1>404 Error</h1><p>The lab route you attempted to access does not exist.</p>";
});

Route::get('/contact', [PageController::class, 'contact']
);

Route::get('/course/{code}/{section}', [PageController::class, 'course']
);

// Home Route
Route::get('/', function () {
    return view('home');
});

// About Route
Route::get('/about', function () {
    return view('about');
});

// Services Route (Optional extension)
Route::get('/services', function () {
    return view('services');
});

// Contact Route
Route::get('/contact', function () {
    return view('contact');
});